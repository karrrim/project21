$(document).ready(function(){
$('.carousel').carousel({

interval:2000


});
});